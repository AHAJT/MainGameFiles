<?php 
    require 'fc-sashimi.php'; 
    function getproduct($_product_code) {
        
    }
?>
<!DOCTYPE html>
<html>

<head>

    <title>VenolChina</title>

    <meta charset="utf-16"></meta>

    <link href="favicon.png" type="image/png" rel="icon" />
    <link href="https://fonts.googleapis.com/css?family=Lato:300,400,500,700&amp;subset=latin-ext" rel="stylesheet">

    <link media="screen" type="text/css" rel="stylesheet" href="styles/reset.css" />
    <link media="screen" type="text/css" rel="stylesheet" href="styles/mainnode.css" />
    <link media="screen" type="text/css" rel="stylesheet" href="styles/ur_controlnode.css" />

    <script src="https://use.fontawesome.com/e8a07ef717.js"></script>

    <meta content="VenolChina" name="title"></meta>
    <meta content="" name="description"></meta>

</head>

<body>
    <?php 
        require 'supplementary/headernode.php'; 
    ?>
    <div class="main-wrapper">
        <main>
            <div class="fc-table-module">
                
                <style type="text/css"> @import url("fc-supplementary/fc-tablegen/fc-table-module.css"); </style>
                <style>
                    .fc-table-module .main-table-container table table td , th {
                        width:13%;
                    }

                    .fc-table-module .main-table-container table table td:first-of-type , th:first-of-type {
                        width:21%;
                    }

                    .fc-table-module .main-table-container table table td:nth-of-type(2) , th:nth-of-type(2) {
                        width: 20%;
                    }

                    .fc-table-module .main-table-container table table td:nth-of-type(3) , th:nth-of-type(3) {
                        width: 20%;
                    }
                </style>

                <?php

                    $_fc_table_data = $_fc_table_module->get_tabledata(['code','date','ammount','price'],'fc-celny',[],['_order_statement' => 'date DESC']);
                    
                ?>
                <h2><?php echo $_lang->getText($_user->_pref_lang,'mag-celny 0'); ?></h2>
                <p><?php echo $_lang->getText($_user->_pref_lang,'ur-control main-log-display 1'); ?><?php echo count($_fc_table_data[1][1]); ?></p>
                <div class="clear"></div>
                <div class="main-table-container">
                    <?php $_fc_table_module->generate_table($_fc_table_data,$_user); ?>
                </div>
            </div>
        </main>
        <aside>

        </aside>
        <div class="clear"></div>
    </div>
</body>
<?php require 'js/headerjs.php'; ?>

</html>
