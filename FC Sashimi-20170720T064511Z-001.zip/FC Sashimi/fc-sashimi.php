<?php
    session_start();

    class _Sys {
        private $sys_Name = 'FruitCake';
        private $sys_Version = 'Sashimi';
        private $sys_Build = '0.0.3';

        const fc_lang_defaultlanguage = 'zh';

        public function getVersion() {
            return $this->sys_Name.' '.$this->sys_Version.' <i class="fa fa-angle-right" aria-hidden="true"></i> '.$this->sys_Build;
        }
        public function getCopyright($type = 0) {
            switch ($type) {
                case 0:
                    return 'Copyright © '.date("Y").' Corporate Paperweight';
                case 1:
                    return '<a href="mailto:corporate.paperweight@gmail.com">Copyright © '.date("Y").' Corporate Paperweight</a>';
            }
        }

    } $_sys = new _Sys();

    class _Database {

        public $pdo;
        function __construct() {
            $config = parse_ini_file('fc-supplementary/fc-config.ini');
            $DB_host = $config['db_host'];
            $DB_user = $config['username'];
            $DB_pass = $config['password'];
            $DB_name = $config['db_name'];

            $this->pdo = new PDO("mysql:host={$DB_host};dbname={$DB_name}",$DB_user,$DB_pass,[PDO::MYSQL_ATTR_INIT_COMMAND => "SET NAMES utf8"]);
            $this->pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
        }

    } $_db = new _Database();

    class _User {

        public $_db;
        public function __construct($_db) {
            $this->_db = $_db;
        }

        /* --- Account login/logout handlers --- */

        public function is_loggedin() {
            if(isset($_SESSION['fc_user_session'])) {
                return true;
            }
        }
        public function log($name,$action,$_bool) {
            date_default_timezone_set('Asia/Shanghai');
            $_date = date('c',time());
            $stmt = $this->_db->pdo->prepare("INSERT INTO `fc-user-log`(username,action,`is_login`,date) VALUES(:uname, :action,:login, :date)");    
            $stmt->execute(['uname'=>$name,'action'=>$action,'login' => $_bool,'date'=>$_date]);

            $stmt = $this->_db->pdo->prepare("UPDATE `fc-user` SET lastactive = :date WHERE username = :user");
            $stmt->execute(['date' => $_date,'user' => $name]);

            return true;
        }
        public function login($_user_name,$_user_pass) {
                $stmt = $this->_db->pdo->prepare("SELECT password FROM `fc-user` WHERE username = :uname");
                $stmt->execute(['uname'=>$_user_name]);
                $_user=$stmt->fetch(PDO::FETCH_NUM);
            
                if($stmt->rowCount() > 0) {
                    if(password_verify($_user_pass, $_user[0])) {
                        $_SESSION['fc_user_session'] = $_user_name;
                        if($this->log($_user_name,'Logged in '.$_SERVER['REMOTE_ADDR'].' ('.$_SERVER['HTTP_X_FORWARDED_FOR'].')',1)) {
                            return true;
                        }
                    } else {
                        return false;
                    }
                }
        }
        public function logout($_user_name) {
            if($this->log($_user_name,'Logged out',1)) {
                session_destroy();
                unset($_SESSION['fc_user_session']);
                return true;
            }
        }
        public function redirect($url) {
            header("Location: $url");
        }
        public function register($_user_name,$_user_pass,$_name,$_registered) {
            $_new_password = password_hash($_user_pass, PASSWORD_DEFAULT);
            date_default_timezone_set('Asia/Shanghai');
            $_setup = date('c',time());

            try {
                $this->_db->pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
                $this->_db->pdo->beginTransaction();

                if ($this->log($_name,'Registered account',0)) {
                    $stmt = $this->_db->pdo->prepare("INSERT INTO `fc-user`(username,password,name,registered,setup) VALUES(:uname, :upass, :name,:registered,:setup)");
                    $stmt->execute(['uname' => $_user_name,'upass' => $_new_password,'name' => $_name,'registered'=>$_registered,'setup' => $_setup]);
                }
            
                $this->_db->pdo->commit();

                return true;
            } catch (Exception $e) {
                $this->_db->pdo->rollBack();
                throw $e;
            }
        }

        /* --- Conditional operators --- */

        public function has_permission($_perm,$_user) {
            $sql = "SELECT $_perm FROM `fc-user` WHERE username = :value";
            $stmt = $GLOBALS['_user']->_db->pdo->prepare($sql);
            $stmt->execute(['value' => $_user]);
            return $stmt->fetch(PDO::FETCH_NUM)[0];
        }

        /* --- Log display handlers --- */

        public function getuser($_user_name) {
            $stmt = $this->_db->pdo->prepare("SELECT name FROM `fc-user` WHERE username = :uname");
            $stmt->execute(['uname'=>$_user_name]);
            return $stmt->fetch(PDO::FETCH_NUM)[0];
        }

    } $_user = new _User($_db);
    $GLOBALS['_user'] = $_user;

    $_user_data = [];
    
    require 'fc-supplementary/fc-tablegen/fc-table-module-functions.php';

    /* --- Handles checks when user opens page --- */

    if(!$_user->is_loggedin()) {
        if (!basename($_SERVER['PHP_SELF']) === 'index.php') {
            $_user->redirect('index.php');
        } 
    } else if(isset($_POST['_logout'])) {
        if($_user->logout($_SESSION['fc_user_session'])) {
            $_user->redirect('index.php');
        }
    } else {
        $_user_id = $_SESSION['fc_user_session'];
        $stmt = $_db->pdo->prepare("SELECT username, langpref FROM `fc-user` WHERE username=:uname");
        $stmt->execute(array("uname"=>$_user_id));
        $_user_data=$stmt->fetch(PDO::FETCH_ASSOC);
    } if(basename($_SERVER['PHP_SELF']) !== 'index.php') {
        if(!$_user->has_permission(substr(basename($_SERVER['PHP_SELF']),0,-4),$_user_data['username'])) {
            $_user->redirect('index.php');
        }
    }

    /* --- Language node (Overrides $_user with _User_Lang) -- */

    include 'fc-supplementary/fc-languagenode.php';
?>