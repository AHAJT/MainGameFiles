<?php require 'fc-sashimi.php'; ?>
<!DOCTYPE html>
<html>

<head>

    <title>VenolChina</title>

    <meta charset="utf-16"></meta>

    <link href="favicon.png" type="image/png" rel="icon" />
    <link href="https://fonts.googleapis.com/css?family=Lato:300,400,500,700&amp;subset=latin-ext" rel="stylesheet">

    <link media="screen" type="text/css" rel="stylesheet" href="styles/reset.css" />
    <link media="screen" type="text/css" rel="stylesheet" href="styles/mainnode.css" />
    <link media="screen" type="text/css" rel="stylesheet" href="styles/ur_controlnode.css" />

    <script src="https://use.fontawesome.com/e8a07ef717.js"></script>

    <meta content="VenolChina" name="title"></meta>
    <meta content="" name="description"></meta>

</head>

<body>
    <?php 
        require 'supplementary/headernode.php'; 
    ?>
    <div class="main-wrapper">
        <main>
            <div class="fc-form-module">
                <style type="text/css"> @import url("fc-supplementary/fc-tablegen/fc-form-module.css"); </style>
                <style>
                    .fc-form-module .main-table-container table tr td:first-of-type{
                        width:28%;
                    }

                    .fc-form-module .main-table-container table tr td:nth-of-type(2) {
                        width:72%;
                    }
                </style>

                <h2><?php echo $_lang->getText($_user->_pref_lang,'ur-control main-log-display 8') ?></h2>
                <?php
                    if (isset($_POST['fc-form-submit'])) {
                        if ($_user->log($_SESSION['fc_user_session'],'Created new user for '.$_POST['fc_form_data']['name'].' with username : '.$_POST['fc_form_data']['username'],0)) {
                            echo '<p>'.$_fc_table_module->submit_table_form($_POST,'Created new user for'.$_POST['fc_form_data']['name'].' at : '.$_POST['fc_form_data']['username']).'</p>';
                        }
                    }
                ?>

                <div class="clear"></div>
                <div class="main-table-container">
                    <?php $_fc_table_module->generate_table_form(['username','name','registered'],'fc-user-temp',[],[$_lang->getText($_user->_pref_lang,'ur-control main-log-display 9'),$_lang->getText($_user->_pref_lang,'ur-control main-log-display 2'),$_lang->getText($_user->_pref_lang,'ur-control main-log-display 10')]); ?>
                    <div class="clear"></div>
                </div>
                <div class="clear"></div>

            </div>
            <div class="fc-table-module">
                
                <style type="text/css"> @import url("fc-supplementary/fc-tablegen/fc-table-module.css"); </style>
                <style> 
                    .fc-table-module .main-table-container table table td , th {
                        width:10%;
                    }

                    .fc-table-module .main-table-container table table td:first-of-type , th:first-of-type {
                        width:20%;
                    }

                    .fc-table-module .main-table-container table table td:nth-of-type(2) , th:nth-of-type(2) {
                        width: 20%;
                    }

                    .fc-table-module .main-table-container table table td:nth-of-type(3) , th:nth-of-type(3) {
                        width: 20%;
                    }
                </style>

                <?php

                    if (isset($_POST['fc_toggle_booleans'])) {

                        $_bool = array_keys($_POST['fc_table_data'])[$_POST['fc_toggle_booleans']+1];
                        $_fc_table_module->toogle_boolean($_POST['fc_table_data']['_table_name'],$_bool,['username' => $_POST['fc_table_data']['username']],['_log' => [$_user_data['username'],$_POST['fc_table_data']['username']]]);

                    }

                    $_fc_table_data = $_fc_table_module->get_tabledata(['username','lastactive','setup','tr_log','ur_control','product_control','mag_celny'],'fc-user',[],['_order_statement' => 'registered DESC']);

                    $_fc_table_data = $_fc_table_module->overwrite_tabledata($_fc_table_data,[[$_lang->getText($_user->_pref_lang,'ur-control main-log-display 2'),$_lang->getText($_user->_pref_lang,'ur-control main-log-display 3'),$_lang->getText($_user->_pref_lang,'ur-control main-log-display 4'),$_lang->getText($_user->_pref_lang,'ur-control main-log-display 5'),$_lang->getText($_user->_pref_lang,'ur-control main-log-display 6'),$_lang->getText($_user->_pref_lang,'ur-control main-log-display 11'),$_lang->getText($_user->_pref_lang,'ur-control main-log-display 7')],[0 => '<?php echo $_func->getuser("$_value"); ?> <i class="fa fa-angle-right" aria-hidden="true"></i> $_value', 3=> '<button type="submit" name="fc_toggle_booleans" value="$_key">$_checkbox</button>', 4=> '<button type="submit" name="fc_toggle_booleans" value="$_key">$_checkbox</button>', 5=> '<button type="submit" name="fc_toggle_booleans" value="$_key">$_checkbox</button>', 6=> '<button type="submit" name="fc_toggle_booleans" value="$_key">$_checkbox</button>']],$_user)
                    
                ?>
                <h2><?php echo $_lang->getText($_user->_pref_lang,'ur-control main-log-display 0'); ?></h2>
                <p><?php echo $_lang->getText($_user->_pref_lang,'ur-control main-log-display 1'); ?><?php echo count($_fc_table_data[1][1]); ?></p>
                <div class="clear"></div>
                <div class="main-table-container">
                    <?php $_fc_table_module->generate_table($_fc_table_data,$_user); ?>
                </div>
            </div>
            <div class="fc-table-module">
                
                <style type="text/css"> @import url("fc-supplementary/fc-tablegen/fc-table-module.css"); </style>

                <?php

                    $_fc_table_data = $_fc_table_module->get_tabledata(['username','name','registered'],'fc-user-temp',[],['_order_statement' => 'registered DESC']);
                    $_fc_table_data = $_fc_table_module->overwrite_tabledata($_fc_table_data,[[$_lang->getText($_user->_pref_lang,'ur-control main-log-display 9'),$_lang->getText($_user->_pref_lang,'ur-control main-log-display 2'),$_lang->getText($_user->_pref_lang,'ur-control main-log-display 10')],[]]);
                    
                ?>
                <h2><?php echo $_lang->getText($_user->_pref_lang,'ur-control main-log-display 12'); ?></h2>
                <div class="clear"></div>
                <div class="main-table-container">
                    <?php $_fc_table_module->generate_table($_fc_table_data); ?>
                </div>
            </div>
        </main>
        <aside>

        </aside>
        <div class="clear"></div>
    </div>
</body>
<?php require 'js/headerjs.php'; ?>

</html>
