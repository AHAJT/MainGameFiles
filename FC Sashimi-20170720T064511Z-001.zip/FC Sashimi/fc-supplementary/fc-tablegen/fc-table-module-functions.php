<?php
    class _fc_table_module {

        public $_db;
        public function __construct($_db) {
            $this->_db = $_db;
        }

        public function log($name,$action,$_bool) {
            date_default_timezone_set('Asia/Shanghai');
            $_date = date('c',time());
            $stmt = $this->_db->pdo->prepare("INSERT INTO `fc-user-log`(username,action,`is_login`,date) VALUES(:uname, :action,:login, :date)");    
            $stmt->execute(['uname'=>$name,'action'=>$action,'login' => $_bool,'date'=>$_date]);

            $stmt = $this->_db->pdo->prepare("UPDATE `fc-user` SET lastactive = :date WHERE username = :user");
            $stmt->execute(['date' => $_date,'user' => $name]);

            return true;
        }

        public function getuser($_user_name) {
            $stmt = $this->_db->pdo->prepare("SELECT name FROM `fc-user` WHERE username = :uname");
            $stmt->execute(['uname'=>$_user_name]);
            return $stmt->fetch(PDO::FETCH_NUM)[0];
        }

        /* --- Table display handlers --- */

        public function get_tableallowed($_table_name) {

                $sql = "DESCRIBE `".$_table_name."`";
                $stmt = $this->_db->pdo->query($sql);
                $_table_columns = $stmt->fetchAll(PDO::FETCH_NUM);

                $_output_table_columns = [];
                foreach ($_table_columns as $_array) {
                    $_output_table_columns[$_array[0]] = $_array[1];
                }

                return $_output_table_columns;

        }

        public function get_tabledata($_select_statements,$_table_name,$_where_statements,$_var_array_input) {


                /* --- Gets associated array input from _var_array_input --- */

                $_limit = '';
                $_order_statement = '';

                if(func_num_args() === 4) {
                    if (isset($_vat_array_input['_limit'])) {
                        $_limit = $_var_array_input['_limit'];
                    }
                    if (isset($_vat_array_input['_order_statement'])) {
                        $_order_statement = $_var_array_input['_order_statement'];
                    }
                }

                /* --- Gets all allowed inputs from table --- */

                $_output_table_columns = $this->get_tableallowed($_table_name);

                /* --- Handles formatting input --- */

                $_set_headers = [];
                $_set_where = '';
                $_set_select = '';
                $_set_group = '';
                $_distinct_table = [];

                if (empty($_select_statements)) {
                    $_set_select = '*';
                } else {
                    foreach ($_select_statements as $_value) {
                        if (isset($_output_table_columns[$_value])) {
                            $_set_headers[$_value] = $_output_table_columns[$_value];
                            $_set_select.="`".str_replace("`", " ", $_value)."`, ";
                        } else {
                            throw new Exception("Value in _select_statements not in $_table_name");
                        }
                    }
                    $_set_select = substr($_set_select, 0, -2);
                } $_table_name = "`".str_replace("`", " ", $_table_name)."` ";
                if(!empty($_var_array_input['_distinct_statement'])) {

                    $sql = "SELECT DISTINCT ".$_var_array_input['_distinct_statement']." FROM ".$_table_name;
                    $stmt = $this->_db->pdo->query($sql);
                    $_distinct_table = $stmt->fetchAll(PDO::FETCH_NUM);

                } if(!empty($_var_array_input['_order_statement'])) {
                    $_order_statement = 'ORDER BY '.$_var_array_input['_order_statement'].' ';
                } if(!empty($_var_array_input['_limit'])) {
                    $_limit = 'LIMIT '.$_var_array_input['_limit'];
                }

                $_copy_headers = $_set_headers;
                $_copy_headers['_table_name'] = $_table_name;
                $_copy_headers['_distinct'] = false;

                if (!empty($_distinct_table)) {
                    $_copy_headers['_distinct'] = true;
                    foreach ($_distinct_table as $_distinct) {

                        $_where_statements[$_var_array_input['_group_statement']] = "'".$_distinct[0]."'";

                        if(!empty($_where_statements)) {
                            $_set_where = "WHERE ";
                            foreach ($_where_statements as $_key => $_value) {
                                if (isset($_output_table_columns[$_key])) {
                                    $_set_where.="`".str_replace("`", " ", $_key)."` = ".$_value." AND ";
                                } else {
                                    throw new Exception("Value in _where_statements not in $_table_name");
                                }
                            }
                            $_set_where = substr($_set_where, 0, -4);
                        }

                        $sql = "SELECT ".$_set_select." FROM ".$_table_name.$_set_where.$_set_group.$_order_statement.$_limit;
                        $stmt = $this->_db->pdo->query($sql);
                        $_table[] = $stmt->fetchAll(PDO::FETCH_NUM);
                    }
                } else {
                    if(!empty($_where_statements)) {
                        $_set_where = "WHERE ";
                        foreach ($_where_statements as $_key => $_value) {
                            if (isset($_output_table_columns[$_key])) {
                                $_set_where.="`".str_replace("`", " ", $_key)."` = ".$_value." AND ";
                            } else {
                                throw new Exception("Value in _where_statements not in $_table_name");
                            }
                        }
                        $_set_where = substr($_set_where, 0, -4);
                    }
                    $_table = [];
                    $sql = "SELECT ".$_set_select." FROM ".$_table_name.$_set_where.$_set_group.$_order_statement.$_limit;
                    $stmt = $this->_db->pdo->query($sql);
                    $_table[0] = $stmt->fetchAll(PDO::FETCH_NUM);
                }

                return [[$_copy_headers,$_set_headers,$_distinct_table],[$_table,$_table]];
        }

        public function concatenate_tabledata($_fc_table_data ,$_var_input) {
            foreach ($_var_input as $_ => $_input) {
                $v1 = $_input[0];
                $v2 = $_input[1];
                $_fc_table_keys = array_keys($_fc_table_data[0][1]);
                unset($_fc_table_data[0][1][$_fc_table_keys[$v2]]);
                foreach ($_fc_table_data[1][1] as $_column_key => $_array) {
                    foreach ($_array as $_distinct_key => $_distinct_array) {
                        $_distinct_array[$v1] = $_distinct_array[$v1].$_input[2].$_distinct_array[$v2];
                        unset($_distinct_array[$v2]);
                        $_distinct_array = array_values($_distinct_array);
                        $_fc_table_data[1][1][$_column_key][$_distinct_key] = $_distinct_array;
                    }
                }
            }
            return $_fc_table_data;
        }

        public function overwrite_tabledata($_table_data,$_var_array_input) {
            /* --- The function is rather meant to be used as a shortcut to keep code clean, useful for multi-language implementation ---
               --- _table_data provided in the following format: [ 0 => [Column names => SQL Column Type, ... => ...], 1... => [Column Data => Value], ... => ...] ---
               --- Provide data in the following format: [ 0 => [Column names, ...], 1... => [Column Data => Value], ... => ... ] ---
               --- Reference old value in data with $_value --- */

            if(isset($_var_array_input[0])) {
                $_old_table_data = $_table_data[0][1];
                $_old_table_keys = array_keys($_old_table_data);
                $_table_data[0][1] = [];

                foreach ($_old_table_keys as $_key => $_value) {
                    $_table_data[0][1][$_var_array_input[0][$_key]] = $_old_table_data[$_value];
                }
            } // !!! Add check to skip undeclared columns --- REWRITE

            if(isset($_var_array_input[1])) {
                $_old_table_data = $_table_data[1][1];

                foreach ($_old_table_data as $_distinct_key => $_distinct) {
                foreach ($_distinct as $_array_key => $_array) {
                    foreach ($_array as $_key => $_value) {
                        if(isset($_var_array_input[1][$_key])) {
                            $_input = $_var_array_input[1][$_key];
                            if (strpos($_input,'$_value') !== false) {
                                $_table_data[1][1][$_distinct_key][$_array_key][$_key] = str_replace('$_value',$_value,$_input);
                            } else {
                               $_table_data[1][1][$_distinct_key][$_array_key][$_key] = $_input;
                            }
                        }
                    }
                }
                }
            }

            return $_table_data;
        }

        public function generate_table($_var_array_input,$_func = NULL) {

            echo '<table>';

            /* --- _table_data provided in the following format: [ 0 => [Column names => SQL Column Type, ... => ...], 1... => [Column Data => Value], ... => ...] ---
               --- _table_data supports included php code, if '<?php' and '?>' is detected, function will run eval() on the string section. !!! supports only one code snippet --- 
               --- reference function containers using _func --- */

            echo '<tr><td><form method="post"><input type="hidden" name="fc_table_data[_table_name]" value="'.$_var_array_input[0][0]["_table_name"].'"/><table><tr>';
            foreach ($_var_array_input[0][1] as $_key => $_value) {
                        echo '<th>'.$_key.'</th>';
            }
            echo '</tr></table></form></td></tr>';

            $_table_allowed = $this->get_tableallowed(str_replace(" ","",str_replace("`", "", $_var_array_input[0][0]["_table_name"])));
            
            foreach ($_var_array_input[1][1] as $_distinct_key => $_distinct_array) {
                if ($_var_array_input[0][0]['_distinct']) {
                    echo '<tr><th style="border-style: solid; border-width: 0 0 1px 0; border-color: #333; text-align:left; padding: 20px 40px 10px 40px;">'.$_var_array_input[0][2][$_distinct_key][0].'</th></tr>';
                }
                foreach ($_distinct_array as $_array_key => $_array) {
                    echo '<tr><td><form method="post"><input type="hidden" name="fc_table_data[_table_name]" value="'.$_var_array_input[0][0]["_table_name"].'"/><table><tr>';

                    $_input_array = array_keys($_var_array_input[0][0]);
                    foreach (array_combine(array_slice($_input_array,0,count($_input_array)-2),$_var_array_input[1][0][$_distinct_key][$_array_key]) as $_input_name => $_input_value) {
                        echo '<input type="hidden" name="fc_table_data['.$_input_name.']" value="'.$_input_value.'" />';
                    }

                    foreach ($_array as $_key => $_value) {

                        if(isset($_table_allowed[array_keys($_var_array_input[0][0])[$_key]])) {
                            unset($_table_allowed[array_keys($_var_array_input[0][0])[$_key]]);
                        }

                        if ($_var_array_input[0][0][array_keys($_var_array_input[0][0])[$_key]] === 'tinyint(1)') {
                            if ($_var_array_input[1][0][$_distinct_key][$_array_key][$_key] == true) {
                                $_value = str_replace('$_key',$_key,$_value);
                                $_value = str_replace('$_checkbox','<i class="fa fa-check-square-o" aria-hidden="true"></i>',$_value);
                            } else if ($_var_array_input[1][0][$_distinct_key][$_array_key][$_key] == false) {
                                $_value = str_replace('$_key',$_key,$_value);
                                $_value = str_replace('$_checkbox','<i class="fa fa-square-o" aria-hidden="true"></i>',$_value);
                            }
                        } if (strpos($_value,'<?php') !== false && strpos($_value,'?>') !== false) {

                            $_open_offset = strpos($_value,'<?php') + 5;
                            $_close_offset = strpos($_value,'?>');

                            echo '<td>'.substr($_value,0,$_open_offset-5);
                            eval(substr($_value,$_open_offset,$_close_offset-$_open_offset));
                            echo substr($_value,$_close_offset+2).'</td>';

                        } else {
                            echo '<td>'.$_value.'</td>';
                        }
                    }
                    echo '</tr></table></form></td></tr>';
                }
            }
            echo '</table>';
        } // --- !!! rewrite with explode for eval execution --- //

        public function generate_table_form($_input_select,$_table_name,$_input_placeholder = [],$_input_overwrite = []) {

            date_default_timezone_set('Asia/Shanghai');
            echo '<form method="post"><input type="hidden" name="fc_form_data[_table_name]" value="'.$_table_name.'"/><table>';

            $sql = "DESCRIBE `".$_table_name."`";
            $stmt = $this->_db->pdo->query($sql);
            $_table_columns = $stmt->fetchAll(PDO::FETCH_NUM);

            $_out_input_select = [];

            foreach ($_input_select as $_key => $_value) {
                $_out_input_select[$_value] = '';
            }

            foreach ($_table_columns as $_column_key => $_array) {

                $_type = 'text';

                if ($_array[1] === 'datetime') {
                    $_type = 'datetime-local" value="'.substr(date('c',time()),0,19).'"';
                }

                if (empty($_input_placeholder[$_column_key])) {
                    $_input_placeholder[$_column_key] = '';
                }

                if (!$_array[2] === 'YES' && !isset($_array[4])) {
                        if (isset($_out_input_select[$_array[0]])) {
                            if (!empty($_input_overwrite[$_column_key])) {
                                echo '<tr><td>'.$_input_overwrite[$_column_key].'</td><td><input type="'.$_type.'" name="fc_form_data['.$_array[0].']" placeholder="'.$_input_placeholder[$_column_key].'" required/></td></tr>';
                            } else {
                                echo '<tr><td>'.$_array[0].'</td><td><input type="'.$_type.'" name="fc_form_data['.$_array[0].']" placeholder="'.$_input_placeholder[$_column_key].'" required/></td></tr>';
                            }
                        } else {
                            throw new Exception("Value required ".$_array[0]);
                        }
                } else {
                    if (!empty($_input_overwrite[$_column_key])) {
                        echo '<tr><td>'.$_input_overwrite[$_column_key].'</td><td><input type="'.$_type.'" name="fc_form_data['.$_array[0].']" placeholder="'.$_input_placeholder[$_column_key].'"/></td></tr>';
                    } else {
                        echo '<tr><td>'.$_array[0].'</td><td><input type="'.$_type.'" name="fc_form_data['.$_array[0].']" placeholder="'.$_input_placeholder[$_column_key].'"/></td></tr>';
                    }
                }
            }

            echo '</table><div class="form-control"><button type="submit" name="fc-form-submit">Zatwierdź</button></div></form>';

        }

        public function submit_table_form($_form_data,$_end_statement = '') {
            
            $_allowed_raw = $this->get_tableallowed($_form_data['fc_form_data']['_table_name']);
            $_allowed_output = [];

            foreach ($_allowed_raw as $_key => $_) {
                $_allowed_output[] = $_key;
            }

            $values = [];
            $set = "";
            foreach ($_allowed_output as $field) {
                if (isset($_form_data['fc_form_data'][$field])) {
                    $set.="`".str_replace("`", "``", $field)."`". "=:$field, ";
                    $values[$field] = $_form_data['fc_form_data'][$field];
                }
            }
            $set = substr($set, 0, -2); 

            try {
                $sql = "INSERT INTO `".$_form_data['fc_form_data']['_table_name']."` SET $set";

                $this->_db->pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
                $this->_db->pdo->beginTransaction();

                $stmt = $this->_db->pdo->prepare($sql);
                $stmt->execute($values);

                $this->_db->pdo->commit();
            } catch (Exception $e) {
                $this->_db->pdo->rollBack();
                throw $e;
            }

            return $_end_statement;

        }

        public function generate_search_form($_table_name) {
            echo '<form method="post"><input type="hidden" name="fc_form_data[_table_name]" value="'.$_table_name.'"/><table></tr>';
            $_allowed_raw = $this->get_tableallowed($_table_name);
            print_r($_allowed_raw);



            echo '<td><button type="submit" name="fc-form-submit">Zatwierdź</button></td></tr></table></form>';
        }

        /* --- Form Functions --- */

        public function preserve_getvariables($_blacklist) {
            foreach($_blacklist as $_var) {
                $_blacklist_assoc[$_var] = '';
            }
            foreach($_GET as $_var => $_value) {
                if(isset($_blacklist_assoc[$_var])) {
                    continue;
                } else {
                    if (isset($_GET[$_var])) {
                        echo '<input type="hidden" name="'. htmlspecialchars($_var) .'" value="'. htmlspecialchars($_GET[$_var]) .'">';
                    }
                }
            }
        }

        public function toogle_boolean($_table_name,$_bool,$_where_statements, $_var_array_input) {

            $_table_name = str_replace("`","", str_replace(" ","",$_table_name));
            $_table_array = $this->get_tableallowed(str_replace("'", "`", $_table_name));
            $_table_array_keys = array_keys($_table_array);

            $_set_where = '';

            if(!empty($_where_statements)) {
                $_set_where = " WHERE ";
                foreach ($_where_statements as $_key => $_value) {
                    $_set_where.="`".str_replace("`", " ", $_key)."` = '".$_value."' AND ";
                }
                $_set_where = substr($_set_where, 0, -4);
            } $_table_name = "`".$_table_name."`";
            $_bool = "`".str_replace("`", " ", $_bool)."` ";

            $sql = "SELECT $_bool FROM ".$_table_name.$_set_where;
            $stmt = $this->_db->pdo->query($sql);
            $_state = (int)!$stmt->fetch(PDO::FETCH_NUM)[0];

            if (isset($_var_array_input['_log'])) {
                $this->log($_var_array_input['_log'][0],'Changed permission '.$_bool.' of : '.$this->getuser($_var_array_input['_log'][1]).' <i class="fa fa-angle-right" aria-hidden="true"></i> '.$_var_array_input['_log'][1],0);
            }

            $sql = "UPDATE ".$_table_name." SET $_bool = $_state ".$_set_where;
            $stmt = $this->_db->pdo->prepare($sql);
            $stmt->execute();
        }

        public function delete_entry($_where_statements) {

            $_table_name = $_where_statements['_table_name'];
            unset($_where_statements['_table_name']);

            $_set_where = '';
            $_table_name = str_replace(" ","",str_replace("`", "", $_table_name));

            $_output_table_columns = $this->get_tableallowed($_table_name);

            if(!empty($_where_statements)) {
                $_set_where = "WHERE ";
                foreach ($_where_statements as $_key => $_value) {
                    if (isset($_output_table_columns[$_key])) {
                        $_set_where.="`".str_replace("`", "", $_key)."` = '".$_value."' AND ";
                    } else {
                        throw new Exception("Value in _where_statements not in $_table_name");
                    }
                }
                $_set_where = substr($_set_where, 0, -4);
            }

            $sql = "DELETE FROM `".$_table_name."` ".$_set_where;
            $stmt = $this->_db->pdo->prepare($sql);
            $stmt->execute([]);
        }

    } $_fc_table_module = new _fc_table_module($_db);
?>