<?php
    class _Lang {

        /* --- Stores all language data, and allows access --- */

        private $fc_zh = ['header-static 0' => 'Chinese Logout',

                        'header-navigation perm 7' => 'Transaction Logs',
                        'header-navigation perm 8' => 'User Control',
                        'header-navigation perm 9' => 'Product Database',
                        'header-navigation perm 10' => 'Customs Warehouse',

                        'loginnode 0' => 'Chinese Login',
                        'loginnode 1' => 'Input username and password',
                        'loginnode 2' => 'User name',
                        'loginnode 3' => 'Password',
                        'loginnode 4' => 'Submit',
                        'loginnode 5' => 'Register account',
                        'loginnode 6' => 'Enter your desired user name, and password',

                        'tr-log main-log-display 0' => 'Ostatnie Logi Transakcji',
                        'tr-log main-log-display 1' => 'Pokazuje : ',
                        'tr-log main-log-display 2' => 'Wyswietl :',
                        'tr-log main-log-display 3' => 'Logi Logowań : ',
                        'tr-log main-log-display 4' => 'Data',
                        'tr-log main-log-display 5' => 'Użytkownik',
                        'tr-log main-log-display 6' => 'Wydarzenie',
                        'tr-log main-log-display 7' => 'Pokaż wszystkie transakcje',
                        'tr-log main-log-display 8' => 'Nie używać podczas pracy innych!',

                        'ur-control main-log-display 0' => 'Podsumowanie Użytkowników',
                        'ur-control main-log-display 1' => 'Pokazuje : ',
                        'ur-control main-log-display 2' => 'Użytkownik',
                        'ur-control main-log-display 3' => 'Ostatnio Aktywny',
                        'ur-control main-log-display 4' => 'Wrejestrowany',
                        'ur-control main-log-display 5' => 'Tr. Log',
                        'ur-control main-log-display 6' => 'Ur. Control',
                        'ur-control main-log-display 7' => 'Customs Warehouse',
                        'ur-control main-log-display 8' => 'Add User',
                        'ur-control main-log-display 9' => 'User name',
                        'ur-control main-log-display 10' => 'Setup',
                        'ur-control main-log-display 11' => 'Product Control',
                        'ur-control main-log-display 12' => 'Użytkownicy niezarejestrowani',

                        'product-control 0' => 'Add a product',
                        'product-control 1' => 'Name of product',
                        'product-control 2' => 'SAE Classification',
                        'product-control 3' => 'Category',
                        'product-control 4' => 'Sub-Category',
                        'product-control 5' => 'Article Number',
                        'product-control 6' => 'Search products',

                        'mag-celny 0' => 'Stock magazynu celnego',];

        private $fc_pl = ['header-static 0' => 'Wyloguj',

                        'header-navigation perm 7' => 'Logi Transakcji',
                        'header-navigation perm 8' => 'Kontrola Uzytkowników',
                        'header-navigation perm 9' => 'Databaza Produktów',
                        'header-navigation perm 10' => 'Magazyn Celny',

                        'loginnode 0' => 'Zaloguj',
                        'loginnode 1' => 'Wpisz nazwe uzytkownika i hasło',
                        'loginnode 2' => 'Nazwa użytkownika',
                        'loginnode 3' => 'Hasło użytkownika',
                        'loginnode 4' => 'Zatwierdź',
                        'loginnode 5' => 'Zarejeztruj konto',
                        'loginnode 6' => 'Wpisz pożądaną nazwe użytkownika i hasło',
                        
                        'tr-log main-log-display 0' => 'Ostatnie logi transakcji',
                        'tr-log main-log-display 1' => 'Pokazuje : ',
                        'tr-log main-log-display 2' => 'Wyswietl :',
                        'tr-log main-log-display 3' => 'Logi logowań : ',
                        'tr-log main-log-display 4' => 'Data',
                        'tr-log main-log-display 5' => 'Użytkownik',
                        'tr-log main-log-display 6' => 'Wydarzenie',
                        'tr-log main-log-display 7' => 'Pokaż wszystkie transakcje',
                        'tr-log main-log-display 8' => 'Nie używać podczas pracy innych!',

                        'ur-control main-log-display 0' => 'Podsumowanie Użytkowników',
                        'ur-control main-log-display 1' => 'Pokazuje : ',
                        'ur-control main-log-display 2' => 'Użytkownik',
                        'ur-control main-log-display 3' => 'Ostatnio Aktywny',
                        'ur-control main-log-display 4' => 'Wrejestrowany',
                        'ur-control main-log-display 5' => 'Logi Transakcji',
                        'ur-control main-log-display 6' => 'Kontrola Użytk.',
                        'ur-control main-log-display 7' => 'Magazyn Celny',
                        'ur-control main-log-display 8' => 'Dodaj użytkownika',
                        'ur-control main-log-display 9' => 'Imie użytkownika',
                        'ur-control main-log-display 10' => 'Utworzony',
                        'ur-control main-log-display 11' => 'Kontrola Produktu',
                        'ur-control main-log-display 12' => 'Użytkownicy niezarejestrowani',

                        'product-control 0' => 'Dodaj produkt',
                        'product-control 1' => 'Nazwa produktu',
                        'product-control 2' => 'Klasyfikacja SAE',
                        'product-control 3' => 'Kategoria',
                        'product-control 4' => 'Pod-Kategoria',
                        'product-control 5' => 'Article Number',
                        'product-control 6' => 'Wyszukaj produkty',
                        
                        'mag-celny 0' => 'Stock magazynu celnego',];

        private $fc_en = ['header-static 0' => 'Logout',

                        'header-navigation perm 7' => 'Transaction Logs',
                        'header-navigation perm 8' => 'User Control',
                        'header-navigation perm 9' => 'Product Database',
                        'header-navigation perm 10' => 'Customs Warehouse',

                        'loginnode 0' => 'Chinese Login',
                        'loginnode 1' => 'Input username and password',
                        'loginnode 2' => 'User name',
                        'loginnode 3' => 'Password',
                        'loginnode 4' => 'Submit',
                        'loginnode 5' => 'Register account',
                        'loginnode 6' => 'Enter your desired user name, and password',

                        'tr-log main-log-display 0' => 'Last transaction logs',
                        'tr-log main-log-display 1' => 'Showing : ',
                        'tr-log main-log-display 2' => 'Show :',
                        'tr-log main-log-display 3' => 'Login logs : ',
                        'tr-log main-log-display 4' => 'Date',
                        'tr-log main-log-display 5' => 'User',
                        'tr-log main-log-display 6' => 'Action',
                        'tr-log main-log-display 7' => 'Show all transactions',
                        'tr-log main-log-display 8' => 'Do not use while others are working!',
                        
                        'ur-control main-log-display 0' => 'User summary',
                        'ur-control main-log-display 1' => 'Showing : ',
                        'ur-control main-log-display 2' => 'User',
                        'ur-control main-log-display 3' => 'Last active',
                        'ur-control main-log-display 4' => 'Registered',
                        'ur-control main-log-display 5' => 'Transaction Logs',
                        'ur-control main-log-display 6' => 'User Control',
                        'ur-control main-log-display 7' => 'Customs Warehouse',
                        'ur-control main-log-display 8' => 'Add User',
                        'ur-control main-log-display 9' => 'User name',
                        'ur-control main-log-display 10' => 'Setup',
                        'ur-control main-log-display 11' => 'Product Control',
                        'ur-control main-log-display 12' => 'Unregistered users',
                        
                        'product-control 0' => 'Add a product',
                        'product-control 1' => 'Name of product',
                        'product-control 2' => 'SAE Classification',
                        'product-control 3' => 'Category',
                        'product-control 4' => 'Sub-Category',
                        'product-control 5' => 'Article Number',
                        'product-control 6' => 'Search products',

                        'mag-celny 0' => 'Customs warehouse stock',];
        
        public function getText($_lang,$index) {
            if (is_null($_lang)) {
                $_lang = _Sys::fc_lang_defaultlanguage;
            }
            switch($_lang) {
                case 'zh': return $this->fc_zh[$index];
                case 'pl': return $this->fc_pl[$index];
                case 'en': return $this->fc_en[$index];
            }
        }
        
    } $_lang = new _Lang();

    class _User_Lang extends _User {

        public $_pref_lang;
        
        public function changeLang($_lang, $user) {
            if (!is_null($user)) {
                $stmt = $this->_db->pdo->prepare("UPDATE `fc-user` SET langpref = :value WHERE username = :user");
                $stmt->execute(['value' => $_lang,'user' => $user]);

                $this->_pref_lang = $_lang;
            } else {
                $this->_pref_lang = $_GET['fc_lang'];
            }
        }

    } $_user = new _User_Lang($_db);

    /* --- Handles setting appropiate language on page --- */

    if(isset($_GET['fc_lang'])) {
        if (empty($_user_data)) {
            $_user->changeLang($_GET['fc_lang'],NULL);
        } else {
            $_user->changeLang($_GET['fc_lang'],$_user_data['username']);
        }
    } else if(!empty($_user_data)) {
        $_user->changeLang($_user_data['langpref'],$_user_data['username']);
    }

?>