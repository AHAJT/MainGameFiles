<?php
    function checkuser($_user) {
        $stmt = $GLOBALS['_user']->_db->pdo->prepare("SELECT username FROM `fc-user-temp` WHERE username = :uname");
        $stmt->execute(['uname'=>$_user]);
        $_=$stmt->fetch(PDO::FETCH_NUM);

        if ($stmt->rowCount() > 0) {
            return true;
        }
    }

    $_required= '';

    if (isset($_SESSION['fc_user_register'])) {
        
        if(isset($_POST['_login'])) {

            $_old_user_name = $_SESSION['fc_user_register'];
            $_user_name = $_POST['_input_username'];
            $_user_pass = $_POST['_input_password'];

            $stmt = $_user->_db->pdo->prepare("SELECT name,registered FROM `fc-user-temp` WHERE username = :uname");
            $stmt->execute(['uname'=>$_old_user_name]);
            $_fetch_data=$stmt->fetch(PDO::FETCH_NUM);

            $stmt = $_user->_db->pdo->prepare('DELETE FROM `fc-user-temp` WHERE username = :uname');
            $stmt->execute(['uname'=>$_old_user_name]);

            session_destroy();

            if($_user->register($_user_name,$_user_pass,$_fetch_data[0],$_fetch_data[1])) {
                header("Location: index.php");
            }
            
        } else {
            $_required = 'required';
        }

    } else if(isset($_POST['_login'])) {
        $_user_name = $_POST['_input_username'];

        if (!empty($_POST['_input_password'])) {
            $_user_pass = $_POST['_input_password'];

            if($_user->login($_user_name,$_user_pass)) {
                $_user->redirect('index.php');
            } else {
                $error[] = 'Wrong credentials';
            }
        } else {
            if (checkuser($_user_name)) {
                echo 'got user';
                $_SESSION['fc_user_register'] = $_user_name;
                header("Location: index.php");
            } else {
                $error[] = 'Wrong credentials';
            }
        }
    }
?>
<style type="text/css">@import url("styles/loginnode.css");</style>
<div class="loginnode">
    <h1><?php if (isset($_SESSION['fc_user_register'])) {echo $_lang->getText($_user->_pref_lang,'loginnode 5');} else { echo $_lang->getText($_user->_pref_lang,'loginnode 0'); } ?></h1>
    <p><?php if (isset($_SESSION['fc_user_register'])) {echo $_lang->getText($_user->_pref_lang,'loginnode 6');} else { echo $_lang->getText($_user->_pref_lang,'loginnode 1'); } ?></p>
    <form method="post">
        <div class="form-wrapper">
            <input type="text" name="_input_username" placeholder="<?php echo $_lang->getText($_user->_pref_lang,'loginnode 2') ?>" required/>
            <input type="password" name="_input_password" placeholder="<?php echo $_lang->getText($_user->_pref_lang,'loginnode 3') ?>" <?php echo $_required; ?>/>
            <button type="submit" name="_login"><?php echo $_lang->getText($_user->_pref_lang,'loginnode 4') ?></button>
            <?php
                if(isset($error)) {
                    foreach($error as $error) {
                        echo '<p>'.$error.'</p>'; 
                    }
                }
            ?>
        </div>
    </form>
</div>