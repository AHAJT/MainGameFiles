<?php
    function getperms($_user) {
        $stmt = $GLOBALS['_user']->_db->pdo->prepare("SELECT * FROM `fc-user`");
        $stmt->execute([]);
        $i = 0;
        $_array_num = [];
        foreach ($stmt->fetch(PDO::FETCH_ASSOC) as $_assoc => $_value) {
            if ($i>6) { $_array_num[$i] = $_assoc; }
            ++$i;
        }
        return $_array_num;
    }
?>
<style type="text/css">@import url("styles/headernode.css");</style>
<header class="full-width">
    <div class="full-width header-static">
        <div class="header-static-left">
            <div class="header-static-logo">
                <object data="images/venol-oil-logo.svg" type="image/svg+xml"></object>
            </div>
            <div class="header-static-country-navigation">
                <span class="header-static-logo-text fixed-visible">VENOL 中国</span>
                <div class="header-static-country">
                    <ul>
                        <li>
                            <form method="get"><button type="submit" name="fc_lang" value="pl">Polski</button></form>
                        </li>
                        <li>
                            <form method="get"><button type="submit" name="fc_lang" value="en">English</button></form>
                        </li>
                        <li>
                            <form method="get"><button type="submit" name="fc_lang" value="zh">普通话</button></form>
                        </li>
                        <li><i class="country-last fa fa-chevron-left" aria-hidden="true"></i></li>
                    </ul>
                </div>
            </div>
        </div>
        <div class="header-static-right">
            <ul>
                <?php
                    if (isset($_SESSION['fc_user_session'])) {
                        echo '<li><div><form method="post"><button type="submit" name="_logout">'.$_lang->getText($_user->_pref_lang,'header-static 0').'</button></form></div></li>';
                    }
                ?>
                <li>
                    <div style="padding:21px 0;"><span><?php echo $_sys->getVersion(); ?></span><span><?php echo $_sys->getCopyright(1); ?></span></div>
                </li>
            </ul>
        </div>
    </div>
    <div class="header-fixed">
        <div class="header-fixed-container">
            <ul>
                <a href="index.php">
                    <li class="selected home-button"><i class="fa fa-building-o"></i></li>
                </a>
                <?php
                    if (isset($_SESSION['fc_user_session'])) {
                        $_perm_array_num = getperms($_user);
                        foreach ($_perm_array_num as $_key => $_field) {
                            if ($_user->has_permission($_field,$_user_data['username'])) {
                                echo '<a href="'.$_field.'.php"><li class="header-navigation"><span>'.$_lang->getText($_user->_pref_lang,'header-navigation perm '.$_key).'</span></li></a>';
                            } 
                        }
                    }
                ?>
            </ul>
        </div>
    </div>
</header>

<div class="full-width page-cover"></div>