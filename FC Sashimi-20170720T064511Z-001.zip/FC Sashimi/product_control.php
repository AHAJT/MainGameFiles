<?php require 'fc-sashimi.php'; ?>
<!DOCTYPE html>
<html>

<head>

    <title>VenolChina</title>

    <meta charset="utf-16"></meta>

    <link href="favicon.png" type="image/png" rel="icon" />
    <link href="https://fonts.googleapis.com/css?family=Lato:300,400,500,700&amp;subset=latin-ext" rel="stylesheet">

    <link media="screen" type="text/css" rel="stylesheet" href="styles/reset.css" />
    <link media="screen" type="text/css" rel="stylesheet" href="styles/mainnode.css" />
    <link media="screen" type="text/css" rel="stylesheet" href="styles/product_controlnode.css" />

    <script src="https://use.fontawesome.com/e8a07ef717.js"></script>

    <meta content="VenolChina" name="title"></meta>
    <meta content="" name="description"></meta>

</head>

<body>
    <?php 
        require 'supplementary/headernode.php'; 
    ?>
    <div class="main-wrapper">
        <main>
            <div class="fc-form-module">
                <style type="text/css"> @import url("fc-supplementary/fc-tablegen/fc-form-module.css"); </style>
                <style>
                    .fc-form-module .main-table-container table tr td:first-of-type{
                        width:28%;
                    }

                    .fc-form-module .main-table-container table tr td:nth-of-type(2) {
                        width:72%;
                    }
                </style>

                <h2><?php echo $_lang->getText($_user->_pref_lang,'product-control 0') ?></h2>
                <?php
                    if (isset($_POST['fc-form-submit'])) {
                        $_input = $_POST;
                        foreach (['001','004','020','060','208','999'] as $_value) {
                            $_input['fc_form_data']['code'] = substr($_input['fc_form_data']['code'], 0, 4).$_value;
                            $_fc_table_module->submit_table_form($_input);
                        }
                        $_user->log($_SESSION['fc_user_session'],'Created new product '.$_input['fc_form_data']['code'],0);
                        echo '<p>Created new product '.$_input['fc_form_data']['name'].' '.$_input['fc_form_data']['type_code'].'</p>';
                    }
                ?>

                <div class="clear"></div>
                <div class="main-table-container">
                    <?php $_fc_table_module->generate_table_form(['name','type_code','type','sub_type','code'],'fc-product-control',['VENOL SYNTHESIS SILVER HC-EC ACTIVE SN CG EC','0W30','PASSENGER CARS','ENGINE OILS','144.001'],[$_lang->getText($_user->_pref_lang,'product-control 1'),$_lang->getText($_user->_pref_lang,'product-control 2'),$_lang->getText($_user->_pref_lang,'product-control 3'),$_lang->getText($_user->_pref_lang,'product-control 4'),$_lang->getText($_user->_pref_lang,'product-control 5')]); ?>
                    <div class="clear"></div>
                </div>
                <div class="clear"></div>

            </div>
            <div class="fc-search-module">
                <style type="text/css"> @import url("fc-supplementary/fc-tablegen/fc-search-module.css"); </style>
                <style></style>

                <h2><?php echo $_lang->getText($_user->_pref_lang,'product-control 6') ?></h2>

                <div class="clear"></div>
                <div class="main-table-container">
                    <?php $_fc_table_module->generate_search_form('fc-product-control'); ?>
                    <div class="clear"></div>
                </div>
                <div class"clear"></div>
            </div>
            <div class="fc-table-module">
                
                <style type="text/css"> @import url("fc-supplementary/fc-tablegen/fc-table-module.css"); </style>
                <style>
                    td:first-of-type , th:first-of-type {
                        width:50%;
                    }
                    td:nth-of-type(2) , th:nth-of-type(2) {
                        width:30%;
                    }
                    td:nth-of-type(3) , th:nth-of-type(3) {
                        width:20%;
                    }
                    .fc-table-module .main-table-container button {
                        padding:0 10px;
                        line-height:16px;
                        margin: 4px 0 4px 10px;

                        border-style: solid;
                        border-width: 2px;
                        border-color: #333;

                        background-color: transparent;

                        color: #333333;
                        font-family: 'Lato', sans-serif;
                        font-style: normal;
                        font-weight: 800;
                        font-size: 10px;
                        letter-spacing: 0;
                    }

                    .fc-table-module .main-table-container button:hover {
                        background-color: #333;
                        color: #F6F6F6;

                        -webkit-transition: color .6s ease 0s;
                        -moz-transition: color .6s ease 0s;
                        transition: color .6s ease 0s;
                    }
                </style>

                <?php

                    if (isset($_POST['fc_delete_entry'])) {
                        $_fc_table_module->delete_entry($_POST['fc_table_data']);
                    }

                    $_fc_table_data = $_fc_table_module->get_tabledata(['name','type_code','type','sub_type','code'],'fc-product-control',[],['_distinct_statement' => 'type','_order_statement' => 'code ASC']);
                    $_fc_table_data = $_fc_table_module->concatenate_tabledata($_fc_table_data,[[0, 1, ' '], [1, 2, ' / ']]);
                    $_fc_table_data = $_fc_table_module->overwrite_tabledata($_fc_table_data,[[$_lang->getText($_user->_pref_lang,'product-control 1'),$_lang->getText($_user->_pref_lang,'product-control 3'),$_lang->getText($_user->_pref_lang,'product-control 5')],[2 => '$_value <button type="submit" name="fc_delete_entry">Delete</button>']])
                    
                ?>
                <h2><?php echo $_lang->getText($_user->_pref_lang,'tr-log main-log-display 0'); ?></h2>
                <p><?php echo $_lang->getText($_user->_pref_lang,'tr-log main-log-display 1'); $_count = 0; foreach ($_fc_table_data[1][1] as $_array) {$_count = $_count + count($_array);} echo $_count; ?></p>
                <div class="clear"></div>
                <div class="main-table-container">
                    <?php $_fc_table_module->generate_table($_fc_table_data); ?>
                </div>
            </div>
        </main>
        <aside>

        </aside>
        <div class="clear"></div>
    </div>
</body>
<?php require 'js/headerjs.php'; ?>

</html>