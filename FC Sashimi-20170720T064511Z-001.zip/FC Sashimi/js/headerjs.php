    <script type = "text/javascript"  src = "js/jquery-3.2.1.min.js"></script>
    <script>
        var $header_container = $('.header-static');
        var $fixedheader_container = $('.header-fixed, .header-fixed-menu')
        var header_height = $header_container.outerHeight(true);

        if ($(window).scrollTop() < header_height) {
            $fixedheader_container.removeClass('fixed');
            $header_container.removeClass('header-margin');
            $header_container.addClass('full-width');
        } else {
            $fixedheader_container.addClass('fixed');
            $header_container.addClass('header-margin');
            $header_container.removeClass('full-width');
        }

        $(window).on('scroll', function () {
            if ($(window).scrollTop() < header_height) {
                $fixedheader_container.removeClass('fixed');
                $header_container.removeClass('header-margin');
                $header_container.addClass('full-width');
            } else {
                $fixedheader_container.addClass('fixed');
                $header_container.addClass('header-margin');
                $header_container.removeClass('full-width');
            }
        });

        $(".header-fixed-container li:not(.home-button),.header-fixed-menu").mouseover(function () {
            $('.page-cover').addClass('darken');
        });
        $(".page-cover").mouseover(function () {
            $('.page-cover').removeClass('darken');
            $('.header-fixed-menu').removeClass('header-visible');
        });

        $(".header-static-logo-text, .header-static-country li i").click(function () {
            $('.header-static-logo-text').toggleClass('fixed-visible');
            $('.header-static-country li').toggleClass('country-visible');
            $('.header-static-country li i').toggleClass('country-visible');
        });
    </script>