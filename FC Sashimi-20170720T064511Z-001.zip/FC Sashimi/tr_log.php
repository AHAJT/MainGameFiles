<?php require 'fc-sashimi.php'; ?>
<!DOCTYPE html>
<html>

<head>

    <title>VenolChina</title>

    <meta charset="utf-16"></meta>

    <link href="favicon.png" type="image/png" rel="icon" />
    <link href="https://fonts.googleapis.com/css?family=Lato:300,400,500,700&amp;subset=latin-ext" rel="stylesheet">

    <link media="screen" type="text/css" rel="stylesheet" href="styles/reset.css" />
    <link media="screen" type="text/css" rel="stylesheet" href="styles/mainnode.css" />
    <link media="screen" type="text/css" rel="stylesheet" href="styles/tr_lognode.css" />

    <script src="https://use.fontawesome.com/e8a07ef717.js"></script>

    <meta content="VenolChina" name="title"></meta>
    <meta content="" name="description"></meta>

</head>

<body>
    <?php require 'supplementary/headernode.php'; ?>
    <div class="main-wrapper">
        <main>
            <div class="fc-table-module">
                <style type="text/css"> @import url("fc-supplementary/fc-tablegen/fc-table-module.css"); </style>
                <style> 
                    .fc-table-module .main-table-container table table td:first-of-type , th:first-of-type {
                        width:20%;
                    }

                    .fc-table-module .main-table-container table table td:nth-of-type(2) , th:nth-of-type(2) {
                        width: 20%;
                    }

                    .fc-table-module .main-table-container table table td:nth-of-type(3) , th:nth-of-type(3) {
                        width: 60%;
                    }
                </style>

                <?php 
                    $_tm_where_statement = ['is_login' => 0];

                    if (isset($_GET['_tr_log_login'])) {
                        if ($_GET['_tr_log_login'] == 1) {
                            $_tr_log_login = '<i class="fa fa-check-square-o" aria-hidden="true"></i>';
                            $_tr_log_logins = 1;
                            unset($_tm_where_statement['is_login']);
                            
                        } else {
                            $_tr_log_login = '<i class="fa fa-square-o" aria-hidden="true"></i>';
                            $_tr_log_logins = 0;
                        }
                    } else {
                        $_tr_log_login = '<i class="fa fa-square-o" aria-hidden="true"></i>';
                        $_tr_log_logins = 0;
                    }

                    if(isset($_GET['_tr_log_limit'])) {
                        $_tm_limit = $_GET['_tr_log_limit'];
                    } else {
                        $_tm_limit = 10;
                    }

                    $_fc_table_data = $_fc_table_module->get_tabledata(['date','username','action'],'fc-user-log',$_tm_where_statement,['_limit' => $_tm_limit,'_order_statement' => 'date DESC']);
                    $_fc_table_data = $_fc_table_module->overwrite_tabledata($_fc_table_data,[[$_lang->getText($_user->_pref_lang,'tr-log main-log-display 4'),$_lang->getText($_user->_pref_lang,'tr-log main-log-display 5'),$_lang->getText($_user->_pref_lang,'tr-log main-log-display 6')],[1 => '<?php echo $_func->getuser("$_value"); ?> <i class="fa fa-angle-right" aria-hidden="true"></i> $_value']],$_user);

                ?>
                <h2><?php echo $_lang->getText($_user->_pref_lang,'tr-log main-log-display 0'); ?></h2>
                <p><?php echo $_lang->getText($_user->_pref_lang,'tr-log main-log-display 1'); echo count($_fc_table_data[1][1]); ?></p>
                <div class="main-table-control">
                    <p>
                        <?php echo $_lang->getText($_user->_pref_lang,'tr-log main-log-display 2'); ?>
                    </p>
                    <form method="get">
                        <?php $_fc_table_module->preserve_getvariables(['_tr_log_login']); ?>
                        <p>
                            <?php echo $_lang->getText($_user->_pref_lang,'tr-log main-log-display 3'); ?>
                            <button type="submit" name="_tr_log_login" value="<?php echo !$_tr_log_logins; ?>">
                                <?php echo $_tr_log_login; ?>
                            </button>
                        </p>
                    </form>
                    <form method="get">
                        <?php $_fc_table_module->preserve_getvariables(['_tr_log_limit']); ?>
                        <button type="submit" name="_tr_log_limit" value="100"><p>100</p></button>
                    </form>
                    <form method="get">
                        <?php $_fc_table_module->preserve_getvariables(['_tr_log_limit']); ?>
                        <button type="submit" name="_tr_log_limit" value="50"><p>50</p></button>
                    </form>
                    <form method="get">
                        <?php $_fc_table_module->preserve_getvariables(['_tr_log_limit']); ?>
                        <button type="submit" name="_tr_log_limit" value="25"><p>25</p></button>
                    </form>
                    <form method="get">
                        <?php $_fc_table_module->preserve_getvariables(['_tr_log_limit']); ?>
                        <button type="submit" name="_tr_log_limit" value="10"><p>10</p></button>
                    </form>
                </div>

                <div class="clear"></div>
                <div class="main-table-container">
                    <?php $_fc_table_module->generate_table($_fc_table_data,$_user); ?>
                </div>
            </div>
            <!--<h2><?php echo $_lang->getText($_user->_pref_lang,'tr-log main-log-display 7'); ?></h2>
            <p><?php echo $_lang->getText($_user->_pref_lang,'tr-log main-log-display 8'); ?></p>-->
        </main>
        <aside>

        </aside>
        <div class="clear"></div>
    </div>
</body>
<?php require 'js/headerjs.php'; ?>

</html>