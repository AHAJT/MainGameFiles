﻿<?php require 'fc-sashimi.php'; ?>
<!DOCTYPE html>
<html>

<head>

    <title>VenolChina</title>

    <meta charset="utf-16"></meta>

    <link href="favicon.png" type="image/png" rel="icon" />
    <link href="https://fonts.googleapis.com/css?family=Lato:300,400,500,700&amp;subset=latin-ext" rel="stylesheet">

    <link media="screen" type="text/css" rel="stylesheet" href="styles/reset.css" />
    <link media="screen" type="text/css" rel="stylesheet" href="styles/mainnode.css" />

    <script src="https://use.fontawesome.com/e8a07ef717.js"></script>

    <meta content="VenolChina" name="title"></meta>
    <meta content="" name="description"></meta>

</head>

<body>
    <?php 
    
        require 'supplementary/headernode.php'; 
        
        if($_user->is_loggedin()) {
        } else {
            require 'supplementary/loginnode.php';
        }
    ?>
</body>
<?php require 'js/headerjs.php'; ?>

</html>
